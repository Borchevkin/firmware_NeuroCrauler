Razor AHRS Firmware and Test Sketch v1.4.1

9 Degree of Measurement Attitude and Heading Reference System
for Sparkfun "9DOF Razor IMU" (SEN-10125 and SEN-10736) 
and "9DOF Sensor Stick" (SEN-10183, SEN-10321 and SEN-10724)

Released under GNU GPL (General Public License) v3.0
Copyright (C) 2011-2012 Quality & Usability Lab, Deutsche Telekom Laboratories, TU Berlin


Infos, updates, bug reports and feedback:
	http://dev.qu.tu-berlin.de/projects/sf-razor-9dof-ahrs

You can find a tutorial at:
	http://dev.qu.tu-berlin.de/projects/sf-razor-9dof-ahrs/wiki/Tutorial



Select your hardware in Arduino/Razor_AHRS/Razor_AHRS.pde under "USER SETUP AREA" / "HARDWARE OPTIONS"!